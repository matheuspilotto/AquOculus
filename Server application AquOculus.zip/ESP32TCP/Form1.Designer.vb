﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Button1 = New Button()
        Button2 = New Button()
        Label2 = New Label()
        Label6 = New Label()
        Button3 = New Button()
        Button4 = New Button()
        Timer1 = New Timer(components)
        IP_address = New TextBox()
        StatusStrip1 = New StatusStrip()
        ToolStripStatusLabel1 = New ToolStripStatusLabel()
        Timer2 = New Timer(components)
        Button5 = New Button()
        txtBoxConsumoInicial = New TextBox()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label1 = New Label()
        ComboBox1 = New ComboBox()
        Label3 = New Label()
        StatusStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Gold
        Button1.BackgroundImageLayout = ImageLayout.None
        Button1.Cursor = Cursors.Hand
        Button1.Font = New Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = Color.Black
        Button1.Location = New Point(48, 202)
        Button1.Margin = New Padding(3, 4, 3, 4)
        Button1.Name = "Button1"
        Button1.Size = New Size(171, 64)
        Button1.TabIndex = 0
        Button1.Text = "Led 1 (off/til78 voltage)"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.Gold
        Button2.BackgroundImageLayout = ImageLayout.None
        Button2.Cursor = Cursors.Hand
        Button2.Font = New Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = Color.Black
        Button2.Location = New Point(48, 308)
        Button2.Margin = New Padding(3, 4, 3, 4)
        Button2.Name = "Button2"
        Button2.Size = New Size(171, 44)
        Button2.TabIndex = 1
        Button2.Text = "Calibrate"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Arial", 13.8F, FontStyle.Bold)
        Label2.ForeColor = Color.Black
        Label2.Location = New Point(714, 267)
        Label2.Name = "Label2"
        Label2.Size = New Size(54, 27)
        Label2.TabIndex = 3
        Label2.Text = ". . . ."
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.Transparent
        Label6.Font = New Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.Black
        Label6.Location = New Point(50, 72)
        Label6.Name = "Label6"
        Label6.Size = New Size(200, 27)
        Label6.TabIndex = 3
        Label6.Text = "ESP32 IP Adress:"
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Gold
        Button3.BackgroundImageLayout = ImageLayout.None
        Button3.Font = New Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button3.ForeColor = Color.Black
        Button3.Location = New Point(196, 125)
        Button3.Margin = New Padding(3, 4, 3, 4)
        Button3.Name = "Button3"
        Button3.Size = New Size(107, 44)
        Button3.TabIndex = 0
        Button3.Text = "Connect"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.Gold
        Button4.BackgroundImageLayout = ImageLayout.None
        Button4.Enabled = False
        Button4.Font = New Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button4.ForeColor = Color.Black
        Button4.Location = New Point(48, 125)
        Button4.Margin = New Padding(3, 4, 3, 4)
        Button4.Name = "Button4"
        Button4.Size = New Size(142, 44)
        Button4.TabIndex = 5
        Button4.Text = "Disconnect"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Timer1
        ' 
        Timer1.Interval = 2000
        ' 
        ' IP_address
        ' 
        IP_address.Font = New Font("Segoe UI Historic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        IP_address.Location = New Point(250, 67)
        IP_address.Margin = New Padding(3, 4, 3, 4)
        IP_address.Name = "IP_address"
        IP_address.Size = New Size(220, 38)
        IP_address.TabIndex = 6
        IP_address.Text = "192.168.137.66"
        ' 
        ' StatusStrip1
        ' 
        StatusStrip1.BackgroundImageLayout = ImageLayout.Stretch
        StatusStrip1.Font = New Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        StatusStrip1.ImageScalingSize = New Size(20, 20)
        StatusStrip1.Items.AddRange(New ToolStripItem() {ToolStripStatusLabel1})
        StatusStrip1.Location = New Point(0, 525)
        StatusStrip1.Name = "StatusStrip1"
        StatusStrip1.Size = New Size(911, 34)
        StatusStrip1.TabIndex = 7
        StatusStrip1.Text = "StatusStrip1"
        ' 
        ' ToolStripStatusLabel1
        ' 
        ToolStripStatusLabel1.BackColor = Color.Transparent
        ToolStripStatusLabel1.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        ToolStripStatusLabel1.Size = New Size(200, 28)
        ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        ' 
        ' Timer2
        ' 
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.Gold
        Button5.BackgroundImageLayout = ImageLayout.None
        Button5.Cursor = Cursors.Hand
        Button5.Font = New Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button5.ForeColor = Color.Black
        Button5.Location = New Point(327, 317)
        Button5.Margin = New Padding(3, 4, 3, 4)
        Button5.Name = "Button5"
        Button5.Size = New Size(220, 35)
        Button5.TabIndex = 8
        Button5.Text = "Set"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' txtBoxConsumoInicial
        ' 
        txtBoxConsumoInicial.Font = New Font("Segoe UI Historic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtBoxConsumoInicial.Location = New Point(326, 263)
        txtBoxConsumoInicial.Margin = New Padding(3, 4, 3, 4)
        txtBoxConsumoInicial.Name = "txtBoxConsumoInicial"
        txtBoxConsumoInicial.Size = New Size(220, 38)
        txtBoxConsumoInicial.TabIndex = 10
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = Color.Transparent
        Label8.Font = New Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.ForeColor = Color.Black
        Label8.Location = New Point(324, 222)
        Label8.Name = "Label8"
        Label8.Size = New Size(173, 27)
        Label8.TabIndex = 9
        Label8.Text = "Initial Read (L)"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.BackColor = Color.Transparent
        Label9.Font = New Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.ForeColor = Color.Black
        Label9.Location = New Point(50, 267)
        Label9.Name = "Label9"
        Label9.Size = New Size(54, 27)
        Label9.TabIndex = 11
        Label9.Text = ". . . ."
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.BackColor = Color.Transparent
        Label10.Font = New Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.ForeColor = Color.Black
        Label10.Location = New Point(48, 356)
        Label10.Name = "Label10"
        Label10.Size = New Size(54, 27)
        Label10.TabIndex = 12
        Label10.Text = ". . . ."
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.Black
        Label1.Location = New Point(638, 222)
        Label1.Name = "Label1"
        Label1.Size = New Size(197, 27)
        Label1.TabIndex = 13
        Label1.Text = "Current Read (L)"
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Items.AddRange(New Object() {"SAGA Y23G", "ENERGYRUS A24HR"})
        ComboBox1.Location = New Point(638, 125)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(208, 28)
        ComboBox1.TabIndex = 14
        ComboBox1.Text = "ENERGYRUS A24HR"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.Black
        Label3.Location = New Point(636, 77)
        Label3.Name = "Label3"
        Label3.Size = New Size(216, 27)
        Label3.TabIndex = 15
        Label3.Text = "Water Meter Model"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(911, 559)
        Controls.Add(Label3)
        Controls.Add(ComboBox1)
        Controls.Add(Label1)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(txtBoxConsumoInicial)
        Controls.Add(Label8)
        Controls.Add(Button5)
        Controls.Add(StatusStrip1)
        Controls.Add(IP_address)
        Controls.Add(Button4)
        Controls.Add(Label6)
        Controls.Add(Label2)
        Controls.Add(Button2)
        Controls.Add(Button3)
        Controls.Add(Button1)
        Margin = New Padding(3, 4, 3, 4)
        Name = "Form1"
        Text = "AquOculus Windows Form Application"
        StatusStrip1.ResumeLayout(False)
        StatusStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents IP_address As TextBox
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Button5 As Button
    Friend WithEvents txtBoxConsumoInicial As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label3 As Label
End Class
